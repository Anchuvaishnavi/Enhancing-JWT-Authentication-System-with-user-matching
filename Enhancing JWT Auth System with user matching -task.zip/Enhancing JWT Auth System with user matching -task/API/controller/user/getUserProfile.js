const bcrypt = require('bcryptjs');
const { user } = require('../../models');
const errorHandle = require('../../../utils/errorHandle');
module.exports = async (req, res) => {
    try {
      
        await user.sync({ force: false })
        let user_id = req.authData.user.id;
        let getuserprofile = await user.findOne({
            order: [
                ['createdAt', 'ASC']
            ],
            attributes: ['full_name','email', 'phone','address'],
            where: {
                id: user_id
            }
        })
        res.status(200).send({
            success: true,
            message: 'User profile',
            result: getuserprofile
        });
        

    } catch (err) {
        console.log(err)
        const { status, message, error } = errorHandle(err);
        res.status(status).json({ status, message, error })
    }
}