const routes = require('express').Router()

auth = require('./auth'),
user= require('./user')


routes.use('/auth', auth);
routes.use('/user',user)





module.exports=routes