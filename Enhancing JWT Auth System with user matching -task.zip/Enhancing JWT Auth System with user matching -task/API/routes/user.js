const routes = require('express').Router();
const jwt = require('../../utils/jwt');



const getUserProfile =require('../controller/user/getUserProfile');
const updateuserprofile=require('../controller/user/updateUserProfile')

routes.get('/profile/user', jwt.validateToken, getUserProfile);
routes.put('profile/updateuser', jwt.validateToken, updateuserprofile)

module.exports = routes;