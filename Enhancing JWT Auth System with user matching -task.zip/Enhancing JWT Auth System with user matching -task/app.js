const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const { Sequelize} = require('sequelize');
const Op = Sequelize.Op;
let async = require("async");
const e = require('express')

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Methods', 'POST, PUT, OPTIONS, DELETE, GET');
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', "*");
    next();
  });
  
  app.use(function returnOps(req, res, next) {
    if (req.method === 'OPTIONS') return res.status(200).send('OK').end();
    next();
  });
  const CONFIG = require('./config');
let sequelize = new Sequelize(
  CONFIG.DB.database,
  CONFIG.DB.username,
  CONFIG.DB.password,
  {
    host: CONFIG.DB.host,
    dialect: CONFIG.DB.dialect,

  }
);
async function dbConnect() {
  try {
    await sequelize.authenticate();
    console.log('Connection has been established successfully.');
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
}
dbConnect()

  app.use(require('./API/routes'));


  //Start Server
const PORT = process.env.PORT || 3003;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}.`);
});