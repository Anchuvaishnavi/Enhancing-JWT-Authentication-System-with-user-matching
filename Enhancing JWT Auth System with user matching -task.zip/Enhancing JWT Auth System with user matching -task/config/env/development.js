module.exports = {
    DB: {
        username: 'root',
        password: '12345',
        database: 'jini_courses',
        host: 'localhost',
        dialect: 'mysql',
      }
}